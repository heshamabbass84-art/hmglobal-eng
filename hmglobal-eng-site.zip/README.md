# HMGLOBAL-ENG.COM Website (English + Arabic lines)

This repository contains the static website for H M GLOBAL ENGINEERING focusing on product lines CONFIRE & RAPDROP.

## Files included
- index.html
- assets/logo.png
- CNAME
- README.md

## Deploy on GitHub Pages (Custom Domain)

1. Create a new **public** repository on GitHub named `hmglobal-eng` or similar.
2. Upload all files and folders from this package to the repository root.
3. In the repository **Settings → Pages** choose **main branch / root** and save.
4. In the **Custom domain** field enter: `hmglobal-eng.com` and enable **Enforce HTTPS** (when available).

## DNS setup (at your domain registrar)
Add the following DNS records pointing to GitHub Pages servers:

- A  @  185.199.108.153
- A  @  185.199.109.153
- A  @  185.199.110.153
- A  @  185.199.111.153
- CNAME  www  <your-github-username>.github.io

Wait up to 24 hours for DNS propagation.

## Notes
- The DOWNLOAD CATALOGUES button is a placeholder and can be linked to PDF files later.
- To edit text or translations, open `index.html` in a text editor and update the content.

Support: info@hmglobal-e.com
